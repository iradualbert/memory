# BST-Visualization
A simple website to visualize binary search tree.

## Initial Thoughts
Working on this project not only helped understand more clearly about BST but also let other users have a better visualization of how BST is like.

## Testing Process:
I invited several of my friends to play around with it and give me feedback. Based on their comments, I fixed some bugs and optimized some features.

Nonetheless, it may still contain some issues;). **Welcome feedbacks and suggestions!**
